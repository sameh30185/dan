<?php

namespace WPML\CF7;

class Constants {

	/**
	 * The CPT slug for contact forms.
	 */
	const POST_TYPE = 'wpcf7_contact_form';

}
